package com.cincc.siphone;

import com.cincc.siphone.core.SipCoreConfig;
//import com.cincc.siphone.ui.TabMainActivity;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;


public class SipPhoneApplication extends Application{
	public static SipPhoneApplication instance = null;
	private SipCoreConfig _sipconfig = new SipCoreConfig();
	//private TabMainActivity _mainTab = null;
	public static SipPhoneApplication GetInstance(){
		return instance;
	}
	public SipPhoneApplication() {
		instance = this;
	}
	
	public  boolean IsPhoneValid()
	{
		if(_sipconfig.getNumber().trim().isEmpty() || 
			_sipconfig.getServer().trim().isEmpty()	|| 
			_sipconfig.getDomain().trim().isEmpty()	||
			_sipconfig.getServerPort() == 0
			)
			return false;
		return true;
	}
/*
	public void SetMainTabActivity(TabMainActivity mTab)
	{
		_mainTab = mTab;
	}
	public TabMainActivity GetMainTabActivity()
	{
		return _mainTab;
	}
	*/
	public SipCoreConfig GetSipCoreConfig()
	{
		return _sipconfig;
	}
	
	public  void GetConfig(Context ct){
        SharedPreferences mPerferences = PreferenceManager.getDefaultSharedPreferences(ct);     
		
		try{
			_sipconfig.setNumber(mPerferences.getString("Account",""));
			_sipconfig.setPassWord(mPerferences.getString("Password",""));
			_sipconfig.setServer(mPerferences.getString("Server",""));
			_sipconfig.setDomain(mPerferences.getString("Domain",""));
			_sipconfig.setServerPort(mPerferences.getInt("Port",0));
		}
		catch(ClassCastException  e){
			
		}
	 }
	public void SetConfig(Context ct){
        SharedPreferences mPerferences = PreferenceManager.getDefaultSharedPreferences(ct);     
        SharedPreferences.Editor mEditor = mPerferences.edit();
        mEditor.putString("Account", _sipconfig.getNumber().trim());
        mEditor.putString("Password", _sipconfig.getPassWord().trim());
        mEditor.putString("Server", _sipconfig.getServer().trim());
        mEditor.putString("Domain", _sipconfig.getDomain().trim());
        mEditor.putInt("Port", _sipconfig.getServerPort());
        mEditor.commit();
  	}

	
}
