package com.cincc.siphone;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.cincc.CINSipPhoneKITDemo.R;
import com.cincc.siphone.core.SipCoreCall;
import com.cincc.siphone.core.SipCoreConfig;
import com.cincc.siphone.core.SipCoreEvent;
import com.cincc.siphone.core.SipCoreEvent.CallState;
import com.cincc.siphone.core.SipCoreEvent.RegistrationState;
import com.cincc.siphone.core.SipCoreEvent.VedioInfo;
import com.cincc.siphone.core.SipCoreUtils;
import com.cincc.siphone.core.SipPhoneCtrl;
import com.cincc.siphone.web.IWebEventHandler;
import com.cincc.siphone.web.SipPhoneWebView;

public class LoginAcvtity extends Activity {
	EditText tvAccout;
	EditText tvPassword;
	EditText tvDomain;
	EditText tvDomainPort;
	CheckBox cbAutoRegister;
	String _tag = "LoginAcvtity";

	boolean bSipService = true;
	private SipPhoneWebView mWebView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.e(_tag, "LoginAcvtity::onCreate");

		CheckPermission();

		setContentView(R.layout.activity_main);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		tvAccout = (EditText) findViewById(R.id.edit_account);
		tvPassword = (EditText) findViewById(R.id.edit_password);
		tvDomain = (EditText) findViewById(R.id.edit_server);
		tvDomainPort = (EditText) findViewById(R.id.edit_port);
		cbAutoRegister = (CheckBox) findViewById(R.id.chk_autoregister);

		GetConfig(this);

        Button bt = (Button) findViewById(R.id.button_register);
		bt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Log.e(_tag, String.format("SipPhoneCtrl Version(%s)",SipPhoneCtrl.Instance().GetVersion()));
				SipPhoneCtrl.Instance().SetNumber(tvAccout.getText().toString().trim());
				SipPhoneCtrl.Instance().SetAuthName(tvAccout.getText().toString().trim());
				SipPhoneCtrl.Instance().SetPassWord(tvPassword.getText().toString().trim());
				SipPhoneCtrl.Instance().SetDomain(tvDomain.getText().toString().trim());
				SipPhoneCtrl.Instance().SetServer(tvDomain.getText().toString().trim());
				SipPhoneCtrl.Instance().SetTraceFlag(3);
				SipPhoneCtrl.Instance().SetFileFlag(0);
				SipPhoneCtrl.Instance().SetDefaultCodec(8);
				SipPhoneCtrl.Instance().SetSipHeartBeatInterval(10);
				SipPhoneCtrl.Instance().SetSipHeartBeatType(0);
				SipPhoneCtrl.Instance().SetSipService(bSipService);
				SipPhoneCtrl.Instance().SetAutoRegister(cbAutoRegister.isChecked());

				SipPhoneCtrl.Instance().SetServerPort(
						SipCoreUtils.StringToInt(tvDomainPort.getText().toString().trim()));


				SetConfig(LoginAcvtity.this);

				Intent intent = new Intent();
				intent.setClass(LoginAcvtity.this, SipMainActivity.class);

				startActivity(intent);

				finish();
			}
		});
		bt.setEnabled(true);

		setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);

		Button bt2 = (Button) findViewById(R.id.button_setting);
		bt2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				SipPhoneCtrl.Instance().SetNumber(tvAccout.getText().toString().trim());
				SipPhoneCtrl.Instance().SetFileFlag(1);
				SipPhoneCtrl.Instance().UploadLog("xylink.cincc.cn", 8078, LoginAcvtity.this);
			}
		});

		SipPhoneCtrl.Instance().RegisterEvent(new SipPhoneCtrl.IEvent() {

			@Override
			public void onRegistrationStateChanged(RegistrationState state, String message) {
			}

			@Override
			public void onCallStateChanged(SipCoreCall call, CallState state, String message) {

			}

			@Override
			public void onMessage(int code, String message) {
				// TODO Auto-generated method stub
				if (code == 100) {
					Toast toast = Toast.makeText(LoginAcvtity.this, message, Toast.LENGTH_LONG);
					View view = toast.getView();
					view.setBackgroundColor(Color.LTGRAY);
					toast.setView(view);
					toast.show();
				}
			}

			@Override
			public void onMediaStatics(VedioInfo vedio) {
				// TODO Auto-generated method stub

			}
			@Override
			public void onCallStatistics(SipCoreEvent.CallStatictics cs)
			{

			}


			@Override
            public void onMediaConsultation(final String key, final String param)
            {
				Log.e(_tag, String.format("onMediaConsultation(%s,%s)",key,param));
            }
			@Override
			public void onDebugEvent(String tagName, String message)
			{

			}

		});


	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.e(_tag, "LoginAcvtity::onPause");
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.e(_tag, "LoginAcvtity::onResume");
	}

	@Override
	protected void onStop() {
		super.onStop();
		Log.e(_tag, "LoginAcvtity::onStop");
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.e(_tag, "LoginAcvtity::onDestroy");
	}

	@Override
	protected void onStart() {
		super.onStart();
		Log.e(_tag, "LoginAcvtity::onStart");
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.addCategory(Intent.CATEGORY_HOME);
			startActivity(intent);
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	protected static void WakeUpBrowserView(Context ctx) {
		if (ctx == null)
			ctx = SipPhoneApplication.GetInstance().getApplicationContext();

		Intent intent = new Intent();
		intent.setClass(ctx, LoginAcvtity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
		ctx.startActivity(intent);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void GetConfig(Context ct) {
		SharedPreferences mPerferences = PreferenceManager.getDefaultSharedPreferences(ct);

		try {

			tvAccout.setText(mPerferences.getString("Account", "15900000004"));
			tvPassword.setText(mPerferences.getString("Password", "00000000"));
			tvDomain.setText(mPerferences.getString("Domain", "192.168.2.176"));
			tvDomainPort.setText(mPerferences.getString("Port", "5066"));
		} catch (ClassCastException e) {

		}
	}

	public void SetConfig(Context ct) {
		SharedPreferences mPerferences = PreferenceManager.getDefaultSharedPreferences(ct);
		SharedPreferences.Editor mEditor = mPerferences.edit();
		mEditor.putString("Account", tvAccout.getText().toString().trim());
		mEditor.putString("Password", tvPassword.getText().toString().trim());
		mEditor.putString("Domain", tvDomain.getText().toString().trim());
		mEditor.putString("Port", tvDomainPort.getText().toString().trim());
		mEditor.commit();
	}
	public void CheckPermission() {
		if (!(ContextCompat.checkSelfPermission(LoginAcvtity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
				!(ContextCompat.checkSelfPermission(LoginAcvtity.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)) {
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, 0);
		} else if (!(ContextCompat.checkSelfPermission(LoginAcvtity.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)) {
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 0);
		} else if (!(ContextCompat.checkSelfPermission(LoginAcvtity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)) {
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
		} else if (!(ContextCompat.checkSelfPermission(LoginAcvtity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
		} else if (!(ContextCompat.checkSelfPermission(LoginAcvtity.this, Manifest.permission.SYSTEM_ALERT_WINDOW) == PackageManager.PERMISSION_GRANTED)) {
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SYSTEM_ALERT_WINDOW}, 0);
		}
	}

}
