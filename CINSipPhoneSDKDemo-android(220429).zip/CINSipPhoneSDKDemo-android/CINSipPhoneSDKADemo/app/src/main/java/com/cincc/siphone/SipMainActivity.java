package com.cincc.siphone;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import com.cincc.siphone.core.SipCoreCall;
import com.cincc.siphone.core.SipCoreEvent;
import com.cincc.siphone.core.SipCoreEvent.CallState;
import com.cincc.siphone.core.SipCoreEvent.RegistrationState;
import com.cincc.siphone.core.SipCoreEvent.VedioInfo;
import com.cincc.siphone.core.SipPhoneCtrl;
//import com.cincc.siphone.ui.TabCallActivity;

import com.cincc.CINSipPhoneKITDemo.R;

import java.util.Timer;
import java.util.TimerTask;

public class SipMainActivity extends Activity {

	public SipMainActivity() {
		// TODO Auto-generated constructor stub
	}

	private boolean bNeedRegister = false;
	private static final String[] numbers = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#" };
	private static final int[] numValues = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 11 };

	private Button btnUnRegister, btnCallOut, btnPickup;
	private TextView sipCallInfo;
	private EditText editNumber;
	private SipCoreCall mCall = null;
	private CallState mCallState = CallState.Idle;
	private RegistrationState mUAState = RegistrationState.RegistrationNone;
	String _tag = "SipMainActivity";


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.acitvity_sip_main);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		btnUnRegister = (Button) findViewById(R.id.button_unregister);
		btnCallOut = (Button) findViewById(R.id.button_callout);
		btnPickup = (Button) findViewById(R.id.button_pickup);
		sipCallInfo = (TextView) findViewById(R.id.sip_call);
		editNumber = (EditText) findViewById(R.id.edit_number);

		btnUnRegister.setOnClickListener(listener);
		btnCallOut.setOnClickListener(listener);
		btnPickup.setOnClickListener(listener);

		setTitle(SipPhoneCtrl.Instance().GetNumber());

		mCall = SipPhoneCtrl.Instance().GetSipCall();
		mUAState = mCall.regState;
		bNeedRegister = SipPhoneCtrl.Instance().GetAutoRegister();
		if(bNeedRegister) {
			if (mCall.regState == RegistrationState.RegistrationNone) {
				btnUnRegister.setEnabled(false);
				btnCallOut.setEnabled(false);
				btnPickup.setEnabled(false);
				sipCallInfo.setText("注册中...");
			} else if (mCall.regState == RegistrationState.RegistrationOk) {
				btnUnRegister.setEnabled(true);
				btnCallOut.setEnabled(true);
				btnPickup.setEnabled(false);
				sipCallInfo.setText("注册成功");
			}
		}
		else{
			btnUnRegister.setEnabled(true);
			btnCallOut.setEnabled(true);
			btnPickup.setEnabled(false);
			sipCallInfo.setText("就绪");
		}



		SipPhoneCtrl.Instance().RegisterEvent(new SipPhoneCtrl.IEvent() {

			@Override
			public void onRegistrationStateChanged(RegistrationState state, String message) {
				Log.e(_tag, state.toString());
				mUAState = state;
				sipCallInfo.setText(state.toString());
				if (state == RegistrationState.RegistrationNone || state == RegistrationState.RegistrationFailed
						|| state == RegistrationState.RegistrationCleared) {
					Intent intent = new Intent();
					intent.setClass(SipMainActivity.this, LoginAcvtity.class);
					startActivity(intent);
					finish();
				} else if (state == RegistrationState.RegistrationOk) {
					btnUnRegister.setEnabled(true);
					btnCallOut.setEnabled(true);
					btnPickup.setEnabled(false);
				}

			}

			@Override
			public void onCallStateChanged(SipCoreCall call, CallState state, String message) {
				Log.e(_tag, message);
				mCall = call;
				if (state == CallState.IncomingReceived) {
					mCall = call;
					if (mCall == null) {
						return;
					}
					editNumber.setVisibility(View.GONE);
					sipCallInfo.setText(String.format("coming a call:[%s]\n", mCall.sNum));
					btnPickup.setText("接通");
					btnPickup.setEnabled(true);
					btnCallOut.setEnabled(false);

				} else if (state == CallState.OutgoingProgress) {
					mCall = call;
					if (mCall == null) {
						return;
					}
					editNumber.setVisibility(View.GONE);
					sipCallInfo.setText(String.format("callouting:[%s]", mCall.sNum));
					btnCallOut.setEnabled(false);
					btnPickup.setText("挂断");
					btnPickup.setEnabled(true);
				} else if (state == CallState.OutgoingRinging) {
					mCall = call;
					if (mCall == null) {
						return;
					}
					editNumber.setVisibility(View.GONE);
					sipCallInfo.setText(String.format("callout op ring:[%s]", mCall.sNum));
					btnCallOut.setEnabled(false);
					btnPickup.setText("挂断");
					btnPickup.setEnabled(true);

				} else if (state == CallState.CallEnd || state == CallState.Error || state == CallState.CallReleased) {
					sipCallInfo.setText("就绪");
					btnPickup.setText("接通");
					btnPickup.setEnabled(false);
					btnCallOut.setEnabled(true);
					editNumber.setVisibility(View.VISIBLE);

				} else if (state == CallState.Connected) {
					sipCallInfo.setText(String.format("connected:[%s]", mCall.sNum));
					btnPickup.setText("挂断");
					btnPickup.setEnabled(true);
					btnCallOut.setEnabled(false);

				}

			}

			@Override
			public void onMessage(int code, String message) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onMediaStatics(VedioInfo vedio) {
				// TODO Auto-generated method stub

			}
			@Override
			public void onCallStatistics(SipCoreEvent.CallStatictics cs)
			{

			}
			@Override
			public void onMediaConsultation(final String key, final String param)
			{

			}
            @Override
            public void onDebugEvent( String tagName, String message)
            {
				Log.e(_tag, String.format("onDebugEvent(%s,%s)",tagName,message));
            }

		});

		SipPhoneCtrl.Instance().Initial(getApplicationContext());
		if(bNeedRegister) {
			if (mCall.regState != RegistrationState.RegistrationOk)
				SipPhoneCtrl.Instance().Register();
		}


		GridView grid = (GridView) findViewById(R.id.dial_button);
		grid.setAdapter(new ArrayAdapter<String>(this, R.layout.dialbutton, numbers));
		grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// GridView grid = (GridView) parent;
				Button text = (Button) view;
				String num = (String) text.getText();
				try {
					if (mCall.callState == CallState.IncomingReceived || mCall.callState == CallState.OutgoingInit)
						return;
					if (mCall.callState == CallState.Connected) {
						for(int i=0;i<numbers.length;i++)
						{
							if(numbers[i].equals(num)){
								SipPhoneCtrl.Instance().SendDtmf(numValues[i]);
								break;
							}
						}
						return;
					}

					String dest = editNumber.getText().toString();
					editNumber.setText(dest + num);
				} catch (Exception e) {
					// probably not a number, absorb the exception
				}

			}
		});
	}



	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// AcpPublic.log(AcpPublic.LogLevel.error, "cinccDemo",
		// "BrowserActivity::onKeyDown");
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.addCategory(Intent.CATEGORY_HOME);
			startActivity(intent);
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}


	private OnClickListener listener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			int id = v.getId();

			if (id == R.id.button_unregister) {
				if(!bNeedRegister){
					Intent intent = new Intent();
					intent.setClass(SipMainActivity.this, LoginAcvtity.class);
					startActivity(intent);
					finish();
					return;
				}
				if (    mUAState == RegistrationState.RegistrationNone ||
						mUAState == RegistrationState.RegistrationCleared) {
					SipPhoneCtrl.Instance().Register();
				} else {
					SipPhoneCtrl.Instance().UnRegister();
				}
			} else if (id == R.id.button_pickup) {
				String text = btnPickup.getText().toString();
				if (text.equals("挂断")) {
					SipPhoneCtrl.Instance().Disconnect();

				} else {
					SipPhoneCtrl.Instance().Answer();
				}
			} else if (id == R.id.button_callout) {
				if (editNumber.getText().length() > 0) {

                    String destNum = editNumber.getText().toString().trim();

					String extraHeader = "";
  					if (SipPhoneCtrl.Instance().DoCall(
							String.format("%s@%s", destNum, SipPhoneCtrl.Instance()
									.GetServer()), extraHeader)) {
						sipCallInfo.setText(String.format("call out:%s", editNumber.getText().toString().trim()));
					} else {
						sipCallInfo.setText("error status can't call");
					}

				}
			}

		}
	};

}
