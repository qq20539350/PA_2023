//
//  CINSipDefines.h
//  CINSipApp
//
//  Created by wushengjun on 16/2/2.
//  Copyright © 2016年 BJCINCC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define CODEC_LIB_WEBRTC
#define CODEC_LIB_CINRTC

#ifdef CODEC_LIB_WEBRTC
  #define SURPPORT_WEBRTC
  #import <WebRTC/RTCEAGLVideoView.h>
  #import <WebRTC/RTCMTLVideoView.h>
#endif

#ifdef CODEC_LIB_CINRTC
#define SURPPORT_CINRTC
#endif

typedef enum emRegistrationState {
    RegistrationNone = 0,
    RegistrationProgress ,
    RegistrationOk ,
    RegistrationCleared ,
    RegistrationFailed
} emRegistrationState;

typedef enum emCallState {
    Idle  = 0,
    IncomingReceived,
    OutgoingInit,
    OutgoingProgress,
    OutgoingRinging,
    OutgoingEarlyMedia,
    Connected,
    StreamsRunning,
    Pausing,
    Paused,
    Resuming,
    Refered,
    Error,
    CallEnd,
    PausedByRemote,
    CallUpdatedByRemote,
    CallIncomingEarlyMedia,
    CallUpdating,
    CallReleased
} emCallState;

enum emTransferMode {
    TransferMode_Udp,
    TransferMode_WebSocket,
    TransferMode_GM,
    TransferMode_Tcp,
    TransferMode_Tls
};
typedef enum emTransferMode emTransferMode;

enum emMediaType {
    NoneVoice,
    AgoraVoice,
    RTPVoice,
    WebrtcVoice
};
typedef enum emMediaType emMediaType;

enum emVideoSize {
    VD_320x240,
    VD_480x360,
    VD_640x360,
    VD_640x480,
    VD_840x480,
    VD_960x720,
    VD_1280x720
};
typedef enum emVideoSize emVideoSize;

enum emVideoMode {
    Webrtc_Fit,
    Webrtc_Full,
    Webrtc_Balanced
};
typedef enum emVideoMode emVideoMode;

enum emMediaState {
    mediaNone,
    mediaAudio,
    mediaVedio,
    mediaAudioVedio,
    mediaAgora
};
typedef enum emMediaState emMediaState;

typedef enum emCallEndCause {
    NoCall = -1,
    NoAnswerCall = 0,
    RejectCall =1,
    ConnectCall =2,
    OtherFailureCall = 3
} emCallEndCause;

typedef  void (^OneStringParamCallBack)(NSString *sValue);
typedef  void (^OneIntParamCallBack)(int code);

////////////////////////////////////
////CallState
////////////////////////////////////
@interface CallState : NSObject
{
    @public
    emCallState callState;
}

- (NSString*) ToString;
-(id)init;

@end

////////////////////////////////////
////RTPCodec
////////////////////////////////////
@interface RTPCodec : NSObject
{
@public
    int codec;
}

- (NSString*) ToString;
-(id)init;

@end

////////////////////////////////////
////RegistrationState
////////////////////////////////////
@interface RegistrationState : NSObject
{
    @public
    emRegistrationState regState;
}

-(NSString*) ToString;
-(id)init;

@end

////////////////////////////////////
////CallEndCause
////////////////////////////////////
@interface CallEndCause : NSObject
{
@public
    emCallEndCause endCause;
}

-(NSString*) ToString;
-(id)init;

@end

////////////////////////////////////
////RtpMediaType
////////////////////////////////////
@interface RtpMediaType : NSObject
{
@public
    emMediaType mediaType;
}

-(NSString*) ToString;
-(id)init;

@end

////////////////////////////////////
////MediaCallStatistics
////////////////////////////////////
@interface MediaCallStatistics : NSObject
{
@public
    int fractionLost;
    int cumulativeLost;
    int extendedMax ;
    int jitterSamples ;
    long rttMs ;
    long bytesSent ;
    int packetsSent ;
    long bytesReceived ;
    int packetsReceived;
}

-(id)init;

@end

////////////////////////////////////
////MediaState
////////////////////////////////////
@interface MediaState : NSObject
{
@public
    emMediaState mediaState;
}

-(NSString*) ToString;
-(id)init;

@end


////////////////////////////////////
////SipCoreCall
////////////////////////////////////
@interface SipCoreCall : NSObject
{
    @public
    RegistrationState* regState;//register status
    RtpMediaType  *mediaType;
    MediaState *mediaState;
    CallState* callState;
    CallEndCause* endCause;
    RTPCodec*  aCodec;
    MediaCallStatistics* callMediaStatistics;

    NSString*   sNum;//对方电话号码
    NSString*   sCurID;////session id
    int         nCode; //error code
    NSString*   sDescription ;//error des
    int         regCode;///register code
    Boolean     bWakeupCall;
    Boolean     bInitial;
    NSString*   sRecordID;////session id
}
-(id)init;
@end

@protocol SIPEventDelegate <NSObject>

@required
/** Occurs when sip register status changed.
@param state RegistrationState  object.
@param message  descprition of register
*/
- (void)OnRegistrationStateChanged:(RegistrationState*)state Message:(NSString *)message;

/** Occurs when sip call status changed.
@param sipcall SipCoreCall  object.
@param state CallState  object
@param message  descprition of caller
*/
- (void)OnCallStateChanged:(SipCoreCall*)sipcall State:(CallState*)state Message:(NSString *)message;
/** Occurs when debug info output.
@param sMsg  debug info
 
*/
- (void)OnDebugMessage:(NSString*)msg;

/** Occurs when recieve special message for sdk or server
@param code  message type.
@param msg  message content.
*/
- (void)OnMessage:(int)code Message:(NSString*)msg;

/** Occurs when recieve special message for sdk or server
@param code  message type.
@param msg  message content.
*/
- (void)OnInfo:(NSString*)conType Message:(NSString*)msg;

/** Occurs when sdk wakeup by apns
@param callNumber  come call key.
@param backGround  backgroud flag.
*/
- (void)OnWakeUp:(NSString*)callNumber BackGround:(Boolean)backGround;

@optional
/** Occurs when mediatype is agora call coming
@param key  call key.
@param param  call param.
@param indentity  call legid.
*/
- (void)OnMediaConsultation:(NSString*)key Param:(NSString*)param Indentity:(NSString*)indentity ;

/** Occurs initial success when Occurs transfer
@param code  code value.
@param des  code description.
*/
- (void)OnInitialStatusChange:(int)code Des:(NSString*)des;

/** Occurs where camera check faces
@param faces  count value.
@param rects  faces rect.
*/
- (void)OnFacePositionChanged:(int)faces Rects:(NSArray*)rects;

/** Occurs when screen record begin or stop
@param key : begin|end
*/
- (void)OnScreenRecord:(NSString*)key ;

@optional
- (void)OnCallStatistics:(NSString*)indentity FractionLost:(int) fractionLost CumulativeLost:(int )cumulativeLost ExtendedMax:(int )extendedMax JitterSamples:(int )jitterSamples RttMs:(long )rttMs;

- (void)OnRtcpCallStatistics:(NSString*)indentity Quality:(int) quality CumulativeLost:(int )cumulativeLost ExtendedMax:(int )extendedMax JitterSamples:(int )jitterSamples RttMs:(long )rttMs;
@end


