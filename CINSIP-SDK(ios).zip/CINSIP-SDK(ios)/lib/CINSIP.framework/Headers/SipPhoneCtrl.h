//
//  CINSipCore.h
//  CINSipApp
//
//  Created by wushengjun on 16/2/1.
//  Copyright © 2016年 BJCINCC. All rights reserved.
//

#import "SipDefines.h"

//////////////////////
//// NYC 1.2
//////////////////

@interface SipPhoneCtrl : NSObject

//attribute


-(NSString*)GetServer;
-(void)SetServer:(NSString*)sValue;
-(NSString*)GetDomain;
-(void)SetDomain:(NSString*)sValue;
-(int)GetServerPort;
-(void)SetServerPort:(int)nValue;
-(NSString*)GetBackServer;
-(void)SetBackServer:(NSString*)sValue;
-(NSString*)GetBackDomain;
-(void)SetBackDomain:(NSString*)sValue;
-(int)GetBackServerPort;
-(void)SetBackServerPort:(int)nValue;
-(NSString*)GetPassWord;
-(void)SetPassWord:(NSString*)sValue;
-(NSString*)GetNumber;
-(void)SetNumber:(NSString*)sValue;
-(NSString*)GetAuthName;
-(void)SetAuthName:(NSString*)sValue;
-(int)GetAuthType;
-(void)SetAuthType:(int)nValue;
-(int)GetDefaultCodec;
-(void)SetDefaultCodec:(int)sValue;
-(NSString*)GetSurpportCodecs;
-(void)SetSurpportCodecs:(NSString*)sValue;
-(int)GetAutoAnswer;
-(void)SetAutoAnswer:(int)nValue;
-(NSString*)GetServiceKey;
-(void)SetServiceKey:(NSString*)sValue;
-(NSArray*)GetAllCodecs;
-(NSString*)GetRouteKey;
-(void)SetRouteKey:(NSString*)sValue;
-(void)SetAppKey:(NSString*)sValue;
-(emTransferMode)GetTransMode;
-(void)SetTransMode:(emTransferMode)mode;
-(emMediaType)GetMeidaType;
-(void)SetMeidaType:(emMediaType)mediaType;
-(int)GetSipEncryptType;
-(void)SetSipEncryptType:(int)nValue;
-(int)GetHeartBeatInterval;
-(void)SetHeartBeatInterval:(int)nValue;
-(int)GetHeartBeatType;
-(void)SetHeartBeatType:(int)nValue;
-(void)SetSurpportVedio:(bool)bValue;
-(bool)GetSurpportVedio;
-(NSString*)GetXPath;
-(void)SetXPath:(NSString*)sValue;
-(bool)GetAutoRegister;
-(void)SetAutoRegister:(bool)bValue;
-(void) SetAgcEnable:(Boolean) enable;
- (Boolean) GetAgcEnable;
- (void) SetNsEnable:(Boolean) enable;
- (Boolean) GetNsEnable;
- (void) SetEcEnable:(Boolean) enable;
- (Boolean) GetEcEnable;
- (void) SetCallStatics:(Boolean) enable;
- (Boolean) GetCallStatics;
-(emVideoMode)GetVideoMode;
-(void)SetVideoMode:(emVideoMode)videoMode;
-(emVideoSize)GetVideoSize;
-(void)SetVideoSize:(emVideoSize)videoSize;
-(void)SetLogPath:(NSString*)sValue;


-(NSString*)GetCaFileName;
-(void)SetCaFileName:(NSString*)sValue;
-(NSString*)GetCertificateFileName;
-(void)SetCertificateFileName:(NSString*)sValue;
-(NSString*)GetPrivateKeyFileName;
-(void)SetPrivateKeyFileName:(NSString*)sValue;


//Method
-(void) SetSipTraceFlag:(int)flags;
-(void) SetSipFileLogFlag:(int)flag;

-(NSString *) GetVersion;
-(int) Initial:(OneIntParamCallBack)initcb;
-(int) UnInitial;
-(int) Register;
-(int) UnRegister;
-(int) DoCall:(NSString*)strNum extraHeader:(NSString*)extra;
-(int) DoIMCall:(NSString*)strNum content:(NSString*)content extraHeader:(NSString*)extra;
-(int) Answer;
-(int) Disconnect;
-(int) Reject:(NSString*)destNum;
-(int) SendMessage:(NSString*)msg;
-(int) SendInfo:(NSString*)conType Msg:(NSString*)msg;
-(int) EnableFaceDetection:(bool)bValue;

-(int) StartScreenRecord;
-(int) StopScreenRecord;
-(int) Share:(NSString*)srcType;
-(int) Update:(bool)bVideo;

-(int) Mute:(bool)bValue;
-(int) SendDtmf:(int)tapKey DtmType:(int)dtmfType;
-(Boolean) SetSpeakMode;
-(Boolean) ChangeCamera;
-(Boolean) SetVedioPlay:(Boolean)bSend Recv:(Boolean)bRecv;


-(int) WakeUp;
-(void) RegisterToRemotePushSever:(UIApplication *)application CallBack:(OneStringParamCallBack)cb;
-(void) didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)pToken;
#ifdef SURPPORT_WEBRTC
-(void) SetVedioView:(RTCEAGLVideoView*)localView VvRemote:(RTCEAGLVideoView*)remoteView;
-(void) SetOutSideBuffer:(CMSampleBufferRef) sampleBuffer;
#endif
-(void) SetVedioComView:(UIView*)localView VvRemote:(UIView*)remoteView;

-(void)  SetMediaConsultationResult:(NSString*)strKey Param:(NSString*)strParam;
-(NSString*) GetSpKey:(NSString*)strKey;
-(SipCoreCall*) GetSipCoreCall;
-(NSString*) UploadLogFile:(NSString *)sServer Port:(int)nPort;

-(void)SetDelegate:(id<SIPEventDelegate>) delegate;
-(id)init;
-(void)dealloc;
+(id) getInstance;
+(void) releaseInstance;


@end
