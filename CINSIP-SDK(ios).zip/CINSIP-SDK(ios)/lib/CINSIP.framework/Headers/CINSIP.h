//
//  CINSIP.h
//  CINSIP
//
//  Created by wushengjun on 16/2/1.
//  Copyright © 2016年 BJCINCC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CINSIP/SipPhoneCtrl.h>

//! Project version number for CINSIP.
FOUNDATION_EXPORT double CINSIPVersionNumber;

//! Project version string for CINSIP.
FOUNDATION_EXPORT const unsigned char CINSIPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CINSIP/PublicHeader.h>


