//
//  CINRTC.h
//  CINRTC
//
//  Created by wushengjun on 16/4/14.
//  Copyright © 2016年 wushengjun. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CINRTC.
FOUNDATION_EXPORT double CINRTCVersionNumber;

//! Project version string for CINRTC.
FOUNDATION_EXPORT const unsigned char CINRTCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CINRTC/PublicHeader.h>


